import numpy as np
import copy
from scipy.optimize import leastsq
from typing import Optional, Sequence


def rotationMat2eulerAngles(rotation_matrix):
    # 提取旋转矩阵的元素
    r11, r12, r13 = rotation_matrix[0]
    r21, r22, r23 = rotation_matrix[1]
    r31, r32, r33 = rotation_matrix[2]

    # 计算欧拉角
    # yaw (绕Z轴旋转)
    thetaz = np.arctan2(r21, r11)

    # pitch (绕Y轴旋转)
    thetay = np.arctan2(-r31, np.sqrt(r32**2 + r33**2))

    # roll (绕X轴旋转)
    thetax = np.arctan2(r32, r33)

    return thetax, thetay, thetaz


def eulerAngles2rotationMat(thetax, thetay, thetaz):
    theta = np.array([thetax, thetay, thetaz], dtype=np.float64)
    cos_theta = np.cos(theta)
    sin_theta = np.sin(theta)
    R_x = np.array(
        [
            [1, 0, 0],
            [0, cos_theta[0], -sin_theta[0]],
            [0, sin_theta[0], cos_theta[0]],
        ],
        dtype=np.float64,
    )

    R_y = np.array(
        [
            [np.cos(thetay), 0, np.sin(thetay)],
            [0, 1, 0],
            [-np.sin(thetay), 0, np.cos(thetay)],
        ],
        dtype=np.float64,
    )

    R_z = np.array(
        [
            [np.cos(thetaz), -np.sin(thetaz), 0],
            [np.sin(thetaz), np.cos(thetaz), 0],
            [0, 0, 1],
        ],
        dtype=np.float64,
    )
    R = np.dot(R_x, np.dot(R_y, R_z))
    return R