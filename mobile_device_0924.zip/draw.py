import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

import numpy as np
import matplotlib.pyplot as plt


fig = plt.figure(dpi=100, figsize=(16, 16))
ax3d = fig.add_subplot(projection='3d')  #创建3d坐标系

t=np.linspace(-np.pi,np.pi,20)
x=np.sin(t)
y=np.cos(t)
z=np.linspace(-1,1,20)
u=np.sin(t+0.1)-x
v=np.cos(t+0.1)-y
w=0.1

x = x[:5]
y = y[:5]
z = z[:5]
u = u[:5]
v = v[:5]
w = 0.1
ax3d.set_xlim(-1, 1)
ax3d.set_ylim(-1, 1)
ax3d.set_zlim(-1, 1)
ax3d.quiver(x,y,z,u,v,w,data=["1", "2", "3", "4", "5"])  #在每一个x,y,z坐标绘制矢量方向为u,v,w的箭头

plt.show()
# plt.savefig("trajectory.jpg")


"""
array([[ 0.98570766, -0.002534  , -0.1684458 ],
       [ 0.07750954,  0.89459184,  0.44011102],
       [ 0.14957499, -0.44687696,  0.88200244]])
array([[ 0.30735109],
       [-0.63833108],
       [-0.01989741]])
"""