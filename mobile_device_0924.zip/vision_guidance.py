from matcher import ELoFTRMatcher, BaseMatcher
import numpy as np
import cv2
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

class VisionGuidance:
    def __init__(self, matcher: BaseMatcher) -> None:
        self.matcher = matcher
        self.template = None
    
    def set_template(self, template: np.ndarray):
        self.template = template
    
    def run(self, img):
        if self.template is None:
            raise ValueError
        result = self.matcher.run(img, self.template)
        # result = self.matcher.get_matrix_H(result)
        # result = self.matcher.decompose_H(result, img, debug=True)
        # result = self.matcher.decompose(result, img, debug=True)
        
        # self.matcher.decompose_by_E(result)
        # self.matcher.visual_decompose(result)
        # vis_decompose_E = result["vis_decompose"]
        self.matcher.decompose_by_H(result)
        self.matcher.visual_decompose(result)
        # vis_decompose_H = result["vis_decompose"]
        # result["vis_decompose"] = np.hstack([vis_decompose_E, vis_decompose_H])
        
        return result
    
    def draw_trajectory(self, save_path):
        fig = plt.figure(dpi=100, figsize=(16, 16))
        ax3d = fig.add_subplot(projection='3d')  #创建3d坐标系

        xs = []
        ys = []
        zs = []
        us = []
        vs = []
        ws = []
        for pos, pose in self.matcher.trajectory_list:
            pose = pose / np.linalg.norm(pose, ord=2)
            u, v, w = pose.flatten()
            x, y, z = pos.flatten()
            xs.append(x)
            ys.append(y)
            zs.append(z)

            us.append(u)
            vs.append(v)
            ws.append(w)
        
        print(self.matcher.trajectory_list)
        ax3d.set_xlim(-1, 1)
        ax3d.set_ylim(-1, 1)
        ax3d.set_zlim(-1, 1)
        ax3d.quiver(xs, ys, zs, us, vs, ws, length=0.2, color="blue")
        if len(xs) > 1:
            ax3d.quiver(
                xs[:-1], 
                ys[:-1], 
                zs[:-1], 
                [x1 - x2 for x1, x2 in zip(xs[1:], xs)], 
                [y1 - y2 for y1, y2 in zip(ys[1:], ys)],
                [z1 - z2 for z1, z2 in zip(zs[1:], zs)],
                color="green"
            )
        # ax3d.plot(xs, ys, zs, color='red')
        # ax3d.plot(xs[:1], ys[:1], zs[:1], color='blue', marker='*')
        # ax3d.plot(xs[-1:], ys[-1:], zs[-1:], color='green', marker='*')
        plt.savefig(save_path)
        plt.show()
        # ax3d.quiver(x,y,z,u,v,w)  #在每一个x,y,z坐标绘制矢量方向为u,v,w的箭头

