MODEL_PATHS = {
    "eloftr": "./models/img_regist/eloftr_outdoor.ckpt",
}