from matcher import ELoFTRMatcher, BaseMatcher
import numpy as np
import cv2

class VisionGuidance:
    def __init__(self, matcher: BaseMatcher) -> None:
        self.matcher = matcher
        self.template = None
    
    def set_template(self, template: np.ndarray):
        self.template = template
    
    def run(self, img):
        if self.template is None:
            raise ValueError
        result = self.matcher.run(img, self.template)
        # result = self.matcher.get_matrix_H(result)
        # result = self.matcher.decompose_H(result, img, debug=True)
        result = self.matcher.decompose(result, img, debug=True)
        
        return result