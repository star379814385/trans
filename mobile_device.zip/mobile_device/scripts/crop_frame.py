import cv2
from pathlib import Path

video_path = "./data/chessboard.mp4"
save_dir = "./data/chessboard_frames"

video = cv2.VideoCapture(video_path)
frame_id = 0
while video.isOpened():
    ret, frame = video.read()
    if frame is None: 
        break
    if ret == True:
        frame_id += 1
        if frame_id % 2 != 0:
            continue
        save_path = str(Path(save_dir) / "{}_{}.jpg".format(Path(video_path).stem, frame_id))
        if not Path(save_path).parent.exists():
            Path(save_path).parent.mkdir(parents=True)
        cv2.imwrite(save_path, frame)
video.release()