import numpy as np

a = np.array([0, 0])
b = np.divide(a, np.linalg.norm(a, ord=2))
print(b)
