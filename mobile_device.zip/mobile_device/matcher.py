
import numpy as np
import cv2
import abc
import matplotlib.cm as cm
from eloftr.src.utils.plotting import make_matching_figure
from eloftr.src.loftr import LoFTR, full_default_cfg, opt_default_cfg, reparameter
import copy
import torch
from model_dict import MODEL_PATHS
from typing import Tuple
import random
from utils import rotationMat2eulerAngles

class BaseMatcher(abc.ABC):
    def __init__(self, **kwargs) -> None:
        self.longsize = 800
        self.divise = 32
        if self.longsize % self.divise != 0:
            raise ValueError
        
    def resize(self, img: np.ndarray):
        h, w = img.shape[:2]
        if w > h:
            new_w = self.longsize
            new_h = (int(new_w / w * h) + self.divise - 1) // self.divise * self.divise
        else:
            new_h = self.longsize
            new_w = (int(new_h / h * w) + self.divise - 1) // self.divise * self.divise

        img_resize = cv2.resize(img, (new_w, new_h))
        return img_resize
            

    def run(self, img: np.ndarray, template: np.ndarray) -> dict:
        img_resize = self.resize(img)
        template_resize = self.resize(template)
        
        img_scale_factor = img_resize.shape[1] / img.shape[1], img_resize.shape[0] / img.shape[0]
        template_scale_factor = template_resize.shape[1] / template.shape[1], template_resize.shape[0] / template.shape[0]
        
        img_points, template_points = self.match(img_resize, template_resize)
        img_points[:, 0] /= img_scale_factor[0]
        img_points[:, 1] /= img_scale_factor[1]
        template_points[:, 0] /= template_scale_factor[0]
        template_points[:, 1] /= template_scale_factor[1]
        return {
            "img_points": img_points,
            "template_points": template_points,
        }
        
    
    @abc.abstractmethod
    def match(self, img: np.ndarray, template: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        pass
    
    def get_matrix_H(self, result: dict):
        img_points = result["img_points"]
        template_points = result["template_points"]
        
        # RANSAC and LSE
        if img_points.shape[0] < 6:
            H = np.eye(3, dtype=np.float32)
            mask = np.zeros((img_points.shape[0], ), dtype=np.bool_)
        else:
            H, mask = cv2.findHomography(img_points, template_points, method=cv2.RANSAC, ransacReprojThreshold=10)
            mask = (mask > 0).flatten()
        n_inlier = np.sum(mask)
        n_points = img_points.shape[0]
        p_inlier = n_inlier / n_points
        print(f"H:\n{H}")
        print("点数：", n_points)
        print("内点率：", p_inlier)
        
        result["H"] = H
        result["p_inlier"] = p_inlier
        result["mask"] = mask
        
        # fx = 1.18295453e+03
        # fy = 1.18708106e+03
        # cx = 6.20392538e+02
        # cy = 3.60822705e+02
        # K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype=np.float32)
        # _, Rs, Ts, Ns = cv2.decomposeHomographyMat(H, K)
        # idx = cv2.filterHomographyDecompByVisibleRefpoints(Rs, Ns, img_points[mask].reshape(-1, 1, 2), template_points[mask].reshape(-1, 1, 2), ).item()
        # R = Rs[idx]
        # T = Ts[idx]
        
        # thetax, thetay, thetaz = rotationMat2eulerAngles(R)
        # thetax_deg  = thetax * 180 / np.pi
        # thetay_deg  = thetay * 180 / np.pi
        # thetaz_deg  = thetaz * 180 / np.pi
        
        # E, mask = cv2.findEssentialMat(img_points, template_points, K, cv2.RANSAC)
        # xx = cv2.decomposeEssentialMat(E, )
        return result 
    
    
    def decompose_H(self, result, img=None, debug=False):
        img_points = result["img_points"]
        template_points = result["template_points"]
        mask = result["mask"] 
        H = result["H"]
        img_points_trans = cv2.perspectiveTransform(img_points.reshape(-1, 1, 2), H)[:, 0]
        
        cxy = np.array([img.shape[1] / 2, img.shape[0] / 2], dtype=np.float32)
        cxy_trans = cv2.perspectiveTransform(cxy.reshape(-1, 1, 2), np.linalg.inv(H))[:, 0].flatten()
        r = min(img.shape[0], img.shape[1]) / 2 * 0.3
        x, y = cxy_trans - cxy
        mod_xy = (x ** 2 + y ** 2) ** 0.5
        if mod_xy < 10:
            x, y = 0, 0
        elif mod_xy > r:
            pass
        # if debug:
            
        #     for pt1, pt2 in zip(img_points[mask].astype(np.int32), img_points_trans[mask].astype(np.int32)):
        #         cv2.arrowedLine(img, pt1, pt2, (0, 255, 0), 1)
            
        #     pt1 = img.shape[1] // 2, img.shape[0] // 2
        #     pt2 = pt1[0] + int(x), pt1[1] + int(y)
        #     cv2.arrowedLine(img, pt1, pt2, (0, 0, 255), 2)
        #     result["vis_decompose_H"] = img
            
            
            
            
            
        #
        fx = 1.18295453e+03
        fy = 1.18708106e+03
        cx = 6.20392538e+02
        cy = 3.60822705e+02
        K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype=np.float32)
        _, Rs, Ts, Ns = cv2.decomposeHomographyMat(H, K)
        if len(Rs) == 1:
            idx = 0
            pass
        else:
            idx = cv2.filterHomographyDecompByVisibleRefpoints(Rs, Ns, img_points[mask].reshape(-1, 1, 2), template_points[mask].reshape(-1, 1, 2), )
            idx = idx.item()
            pass
        R = Rs[idx]
        T = Ts[idx]
        thetax, thetay, thetaz = np.array(rotationMat2eulerAngles(R)) * 180 / np.pi
        
        pitch = thetax  # 俯仰角
        yaw = thetay    # 偏航角
        roll = thetaz   # 翻转角
        c_up = T[0].item()
        c_right = T[1].item()
        c_forward = T[2].item()
        
        if debug:
            for i, var_str in enumerate(["pitch", "yaw", "roll", "c_up", "c_right", "c_forward"]):
                cv2.putText(img, f"{var_str}: {eval(var_str):.2f}", (40, 40 + 40 * i), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 3)
            result["vis_decompose"] = img
        return result
        
    
    def decompose(self, result, img=None, debug=False):
        img_points = result["img_points"]
        template_points = result["template_points"]
        
        # RANSAC and LSE
        # fx = 1
        # fy = 1
        # cx = img.shape[1] / 2
        # cy = img.shape[0] / 2
        # K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype=np.float32)
        
        fx = 1.18295453e+03
        fy = 1.18708106e+03
        cx = 6.20392538e+02
        cy = 3.60822705e+02
        K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]], dtype=np.float32)
        
        if img_points.shape[0] < 6:
            E = np.eye(3, dtype=np.float64)
            mask = np.zeros((img_points.shape[0], ), dtype=np.bool_)
        else:
            E, mask = cv2.findEssentialMat(img_points, template_points, K, cv2.LMEDS)
            # H, mask = cv2.findHomography(img_points, template_points, method=cv2.RANSAC, ransacReprojThreshold=10)
            mask = (mask > 0).flatten()
            
        # E = np.eye(3, dtype=np.float64)
        
        print(f"E:\n{E}")
            
        n_inlier = np.sum(mask)
        n_points = img_points.shape[0]
        p_inlier = n_inlier / n_points
        print("点数：", n_points)
        print("内点率：", p_inlier)
        
        # R1, R2, t = cv2.decomposeEssentialMat(E)
        # print(R1)
        # print(R2)
        # print(t)
        _, R, T, _ = cv2.recoverPose(E, img_points[mask], template_points[mask], K)
        
        # R, T = cv2.decomposeHomographyMat(result["H"], K)
        
        print("R:", R)
        print("T:", T)
        thetax, thetay, thetaz = np.array(rotationMat2eulerAngles(R)) * 180 / np.pi
        
        pitch = thetax  # 俯仰角
        yaw = thetay    # 偏航角
        roll = thetaz   # 翻转角
        c_up = T[0].item()
        c_right = T[1].item()
        c_forward = T[2].item()
        
        if debug:
            for i, var_str in enumerate(["pitch", "yaw", "roll", "c_up", "c_right", "c_forward"]):
                cv2.putText(img, f"{var_str}: {eval(var_str):.2f}", (40, 40 + 40 * i), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 3)
            result["vis_decompose"] = img
        
        return result
        
        

    def get_matrix_F(self, result: dict):
        img_points = result["img_points"]
        template_points = result["template_points"]
        
        # RANSAC and LSE
        if img_points.shape[0] < 6:
            H = np.eye(3, dtype=np.float32)
            mask = np.zeros((img_points.shape[0], ), dtype=np.bool_)
        else:
            H, mask = cv2.findFundamentalMat(img_points, template_points, cv2.RANSAC, 10)
            mask = (mask > 0).flatten()
        n_inlier = np.sum(mask)
        n_points = img_points.shape[0]
        p_inlier = n_inlier / n_points
        print("点数：", n_points)
        print("内点率：", p_inlier)
        
        result["H"] = H
        result["p_inlier"] = p_inlier
        result["mask"] = mask
        return result 
    
    def visual_H(self, img, template, result, vis_merge=True):
        img_points = result["img_points"]
        template_points = result["template_points"]
        H = result["H"]
        mask = result["mask"] 
        
        img_trans = cv2.warpPerspective(img, H, (template.shape[1], template.shape[0]))
        img_points_trans = cv2.perspectiveTransform(img_points[:, None], H)[:, 0]
        
        if vis_merge:
            img_vis = cv2.addWeighted(img_trans, 0.7, template, 0.3, 0)
            for pt1, pt2, mask_flag in zip(img_points_trans.astype(np.int32), template_points.astype(np.int32), mask):
                cv2.circle(img_vis, pt1, 1, (0, 0, 255), 1)
                cv2.circle(img_vis, pt2, 1, (0, 255, 0), 1)
                if not mask_flag:
                    cv2.line(img_vis, pt1, pt2, (255, 0, 0), 1)
                else:
                    cv2.line(img_vis, pt1, pt2, (0, 255, 0), 1)
        else:
            img_vis = np.concatenate([img_trans, template], axis=0)
            for pt1, pt2 in zip(img_points_trans.astype(np.int32), template_points.astype(np.int32)):
                pt2[1] += img_trans.shape[0]
                cv2.circle(img_vis, pt1, 1, (0, 0, 255), 1)
                cv2.circle(img_vis, pt2, 1, (0, 255, 0), 1)
                if random.random() < 0.1:
                    cv2.line(img_vis, pt1, pt2, (255, 0, 0), 1)
        return img_vis
    

class ELoFTRMatcher(BaseMatcher):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        # You can choose model type in ['full', 'opt']
        model_type = 'full' # 'full' for best quality, 'opt' for best efficiency

        # You can choose numerical precision in ['fp32', 'mp', 'fp16']. 'fp16' for best efficiency
        precision = 'fp32' # Enjoy near-lossless precision with Mixed Precision (MP) / FP16 computation if you have a modern GPU (recommended NVIDIA architecture >= SM_70).
        if model_type == 'full':
            _default_cfg = copy.deepcopy(full_default_cfg)
        elif model_type == 'opt':
            _default_cfg = copy.deepcopy(opt_default_cfg)
            
        if precision == 'mp':
            _default_cfg['mp'] = True
        elif precision == 'fp16':
            _default_cfg['half'] = True
            
        # print(_default_cfg)
        matcher = LoFTR(config=_default_cfg)

        matcher.load_state_dict(torch.load(MODEL_PATHS["eloftr"], map_location="cpu")['state_dict'])
        matcher = reparameter(matcher) # no reparameterization will lead to low performance

        if precision == 'fp16':
            matcher = matcher.half()

        matcher = matcher.eval().cuda()

        self.precision = precision
        self.matcher = matcher
        
    def match(self, img: np.ndarray, template: np.ndarray) -> dict:
        precision = self.precision
        
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        template = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)

        if self.precision == 'fp16':
            img0 = torch.from_numpy(img)[None][None].half().cuda() / 255.
            img1 = torch.from_numpy(template)[None][None].half().cuda() / 255.
        else:
            img0 = torch.from_numpy(img)[None][None].cuda() / 255.
            img1 = torch.from_numpy(template)[None][None].cuda() / 255.
        batch = {'image0': img0, 'image1': img1}
        # Inference with EfficientLoFTR and get prediction
        with torch.no_grad():
            if precision == 'mp':
                with torch.autocast(enabled=True, device_type='cuda'):
                    self.matcher(batch)
            else:
                self.matcher(batch)
            mkpts0 = batch['mkpts0_f'].cpu().numpy()
            mkpts1 = batch['mkpts1_f'].cpu().numpy()
            # mconf = batch['mconf'].cpu().numpy()
        return mkpts0, mkpts1