from vision_guidance import VisionGuidance
from matcher import ELoFTRMatcher
import cv2
from pathlib import Path

if __name__ == "__main__":
    matcher = ELoFTRMatcher()
    vg = VisionGuidance(matcher)
    template_path = "./data/demo_frames/demo_540.jpg"
    template = cv2.imread(template_path, cv2.IMREAD_COLOR)
    print(template.shape)
    vg.set_template(template)
    
    img_dir = "./data/demo_frames"
    save_dir = "./data/demo_frames_vis"
    if not Path(save_dir).exists():
        Path(save_dir).mkdir(parents=True)
    img_paths = [str(img_path) for img_path in Path(img_dir).glob("*.jpg")]
    # img_paths = ["/home/lrh/code/mobile_device/data/demo_frames/demo_530.jpg"]
    for img_path in img_paths:
        img = cv2.imread(img_path, cv2.IMREAD_COLOR)
        result = vg.run(img)
        vis_decompose_H = result["vis_decompose"]
        save_path = str(Path(save_dir) / Path(img_path).name)
        cv2.imwrite(save_path, vis_decompose_H)
        
    # img_vis = matcher.visual_H(img, template, result, vis_merge=True)
    # cv2.imwrite("vis1.jpg", img_vis)
    
    # matcher.decompose(result["H"])